package quiz.application;

import javax.swing.*;
import java.awt.*;

public class Result extends JFrame {

    Result(String name) {
        setBounds(300, 100, 800, 600);
        getContentPane().setBackground(Color.WHITE);
        setLayout(new BorderLayout());

        JLabel title = new JLabel("Review Your Answers", SwingConstants.CENTER);
        title.setFont(new Font("Tahoma", Font.BOLD, 24));
        title.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        add(title, BorderLayout.NORTH);

        String[] columnNames = {"Q#", "Question", "Your Answer", "Correct Answer"};
        String[][] data = new String[10][4];

        for (int i = 0; i < 10; i++) {
            data[i][0] = (i + 1) + ".";
            data[i][1] = Quiz.questions[i][0];
            data[i][2] = Quiz.useranswers[i][0].equals("") ? "Not Attempted" : Quiz.useranswers[i][0];
            data[i][3] = Quiz.answers[i][1];
        }

        JTable table = new JTable(data, columnNames);
        table.setFont(new Font("Tahoma", Font.PLAIN, 16));
        table.setRowHeight(30);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        JButton back = new JButton("Back to Home");
        back.setFont(new Font("Tahoma", Font.PLAIN, 18));
        back.setBackground(new Color(30, 144, 255));
        back.setForeground(Color.WHITE);
        back.addActionListener(e -> {
            setVisible(false);
            new Login(); // Go back to login or main menu
        });
        add(back, BorderLayout.SOUTH);

        setVisible(true);
    }
}