package quiz.application;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Login extends JFrame implements ActionListener {
    JButton rules;
    JTextField tfname;

    Login() {
        setTitle("Simple Minds - Login");
        setBounds(400, 200, 800, 400);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        // Load and add image
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/login.jpeg"));
        Image i2 = i1.getImage().getScaledInstance(250, 250, Image.SCALE_SMOOTH);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(30, 60, 250, 250);
        add(image);

        JLabel heading = new JLabel("Simple Minds");
        heading.setBounds(350, 30, 300, 45);
        heading.setFont(new Font("Viner Hand ITC", Font.BOLD, 30));
        heading.setForeground(new Color(30, 144, 254));
        add(heading);

        JLabel name = new JLabel("Enter your name:");
        name.setBounds(320, 100, 200, 30);
        name.setFont(new Font("Mongolian Baiti", Font.BOLD, 18));
        add(name);

        tfname = new JTextField();
        tfname.setBounds(460, 100, 250, 30);
        tfname.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        add(tfname);

        rules = new JButton("Rules");
        rules.setBounds(460, 160, 100, 30);
        rules.setBackground(new Color(30, 144, 254));
        rules.setForeground(Color.WHITE);
        rules.addActionListener(this);
        add(rules);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        String name = tfname.getText();
        if (!name.trim().isEmpty()) {
            setVisible(false);
            new Rules(name);
        } else {
            JOptionPane.showMessageDialog(this, "Please enter your name");
        }
    }

    public static void main(String[] args) {
        new Login().setVisible(true);
    }
}