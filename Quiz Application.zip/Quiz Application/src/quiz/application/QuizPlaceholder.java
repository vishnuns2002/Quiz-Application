package quiz.application;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class QuizPlaceholder extends JFrame {
    private JLabel message, countdownLabel;
    private int countdown = 10; // 10 seconds countdown

    QuizPlaceholder(String name) {
        setTitle("Quiz - Simple Minds");
        setSize(600, 400);
        setLocation(400, 200);
        getContentPane().setBackground(Color.WHITE);
        setLayout(new BorderLayout());

        message = new JLabel("Quiz will start shortly, " + name + "!", JLabel.CENTER);
        message.setFont(new Font("Tahoma", Font.PLAIN, 20));
        add(message, BorderLayout.CENTER);

        countdownLabel = new JLabel("Starting in: " + countdown + " seconds", JLabel.CENTER);
        countdownLabel.setFont(new Font("Tahoma", Font.BOLD, 22));
        countdownLabel.setForeground(Color.RED);
        add(countdownLabel, BorderLayout.SOUTH);

        setVisible(true);

        // Countdown timer
        Timer countdownTimer = new Timer(1000, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                countdown--;
                countdownLabel.setText("Starting in: " + countdown + " seconds");
                if (countdown == 0) {
                    ((Timer) e.getSource()).stop();
                    setVisible(false);
                    new Quiz(name);
                }
            }
        });
        countdownTimer.start();
    }

    public static void main(String[] args) {
        new QuizPlaceholder("User");
    }
}